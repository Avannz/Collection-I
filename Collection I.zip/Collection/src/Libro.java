public class Libro extends Biblioteca{

    String titulo;
    String autor;
    double precio;

    String año_publicacion;

    public Libro(String titulo, String autor, double precio, String año_publicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.precio = precio;
        this.año_publicacion = año_publicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getAño_publicacion() {
        return año_publicacion;
    }

    public void setAño_publicacion(String año_publicacion) {
        this.año_publicacion = año_publicacion;
    }
}

