//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Biblioteca biblioteca = new Biblioteca();
        boolean flag;
        double precio = 0;
        int total_libros = 0;

        biblioteca.agregar(new Libro("Libro uno", "Autor uno", 1000, "2005"));
        biblioteca.agregar(new Libro("Libro dos", "Autor dos", 1300, "2015"));
        biblioteca.agregar(new Libro("Libro tres", "Autor tres", 5000, "2025"));

        biblioteca.eliminar("Libro uno");
        biblioteca.mostrar();

        flag = biblioteca.buscar_titulo("Libro uno");
        System.out.println(flag); /// Arroja FALSE, Libro Uno eliminado exitosamente.

        precio = biblioteca.calcular_precio();
        System.out.println(precio);

        total_libros = biblioteca.total_inventario();
        System.out.println(total_libros);
        }
    }
