import java.util.ArrayList;
import java.util.HashMap;

public class Biblioteca {

    private HashMap<String, Libro> biblioteca;

    public Biblioteca() {
        this.biblioteca = new HashMap<>();
    }

    public void agregar(Libro nuevo_libro){

        biblioteca.put(nuevo_libro.getTitulo(), nuevo_libro);
    }

    public void eliminar(String titulo){

        biblioteca.remove(titulo);
    }

    public void mostrar()
    {
        for( Libro aux : biblioteca.values()) {
            System.out.println(aux.toString());
        }
    }

    public boolean buscar_titulo(String titulo){
        for(Libro aux : biblioteca.values()) {
            if(aux.getTitulo().equals(titulo)) {

                return true;
            }
        }
        return false;
    }

    public double calcular_precio(){

        double total = 0;

        for(Libro aux : biblioteca.values())
        {
            total += aux.getPrecio();
        }
        return total;
    }

    public int total_inventario()
    {
        return biblioteca.size();
    }


}
